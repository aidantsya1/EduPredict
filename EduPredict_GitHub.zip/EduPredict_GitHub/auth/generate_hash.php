<?php
echo password_hash("Edu@1234", PASSWORD_DEFAULT);
